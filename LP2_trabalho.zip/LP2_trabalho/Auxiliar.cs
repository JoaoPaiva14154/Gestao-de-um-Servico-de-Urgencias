﻿/*      Trabalho Prático LP2
 *  |Gestão Urgência|
 * 
 *  José Paulo Antunes      a11582@alunos.ipca.pt
 *  João Paiva              a14154@alunos.ipca.pt
 *  
 *  IPCA 2019/2020
 */



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LP2_trabalho
{

    /// <summary>
    /// Classe que contém funções auxiliares de cópia e organização de arrays 
    /// </summary>

    class Auxiliar
    {
        #region METODOS
        /// <summary>
        /// Copia os dados de um array para um novo array com tamanho dos utentes
        /// </summary>
        /// <param name="ut">Array de utentes</param>
        /// <param name="nUtentes">numero de utentes</param>
        /// <returns>Array de utente</returns>
        public Utente[] NovArr(Utente[] ut, int nUtentes)
        {
            Utente[] aux = new Utente[nUtentes];

            for (int i = 0; i < nUtentes; i++)
            {
                aux[i] = ut[i];
            }

            return aux;
        }

        /// <summary> 
        /// Copia os dados de um array para outro array maior  (polimorfismo)
        /// </summary>
        /// <param name="ut">Array de utentes menor</param>
        /// <param name="ut2">Array de utentes maior</param>
        /// <returns>array de utente</returns>
        public Utente[] NovArr(Utente[] ut, Utente[] ut2)
        {
            int j = 0;

             while (ut2[j] != null)
             {
                 j++;
             }   

            ut.CopyTo(ut2, j);

            return ut2;
        }

        /// <summary>
        /// Copia os dados do array para outro array (medico)
        /// </summary>
        /// <param name="med">Array Medico menor</param>
        /// <param name="med2">Array medico maior</param>
        /// <returns>Array de medico</returns>
        public Medico[] NovArr(Medico[] med, Medico[] med2)
        {
            int j = 0;

            while (med2[j] != null)
            {
                j++;
            }

            

            med.CopyTo(med2, j);


            return med2;
        }

        /// <summary>
        /// Copia dados do array para outro array maior (enfermeiro)
        /// </summary>
        /// <param name="enf">Array enf menor</param>
        /// <param name="enf2">Array enf maior</param>
        /// <returns>Array de enfermeiro</returns>
        public Enfermeiro[] NovArr(Enfermeiro[] enf, Enfermeiro[] enf2)
        {
            int j = 0;

            while (enf2[j] != null)
            {
                j++;
            }

            enf.CopyTo(enf2, j);

            return enf2;
        }

        /// <summary>
        /// Ordena utentes por prioridade de pulseira
        /// </summary>
        /// <param name="ut">Array de utentes</param>
        /// <returns>Array de utentes</returns>
        public Utente[] OrgUtentes(Utente[] ut)
        {
            ut = ut.OrderBy(c => c.Prioridade).ToArray(); //organiza os utentes de prioritisa por pulseira 

            return ut;
        }
        #endregion

    }
}
