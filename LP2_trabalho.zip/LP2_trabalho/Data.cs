﻿/*      Trabalho Prático LP2
 *  |Gestão Urgência|
 * 
 *  José Paulo Antunes      a11582@alunos.ipca.pt
 *  João Paiva              a14154@alunos.ipca.pt
 *  
 *  IPCA 2019/2020
 */


using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace LP2_trabalho
{

    /// <summary>
    /// Classe que contém funções para armazenar os dados em ficheiros e ler dados de ficheiros 
    /// </summary>

    class Data
    {
        #region METODOS
        /// <summary>
        /// Guarda em ficheiro binario os dados de utentes. Os dados são guardados em ficheiros separados
        /// </summary>
        /// <param name="atendidos">Array de atendidos</param>
        /// <param name="totalUtentes">Array dos utentes totais</param>
        /// <param name="atendENAtend">Utentes que passaram pela triagem, atendidos ou não</param>
        /// <param name="med">Array de medicos</param>
        /// <param name="enf">Array de enfermeiros</param>
        /// <returns></returns>
        public string GuardaEmBin(Utente[] atendidos,Utente[] totalUtentes,Utente[] atendENAtend,Medico[] med,Enfermeiro[]enf)  
        {

            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream("Atendidos.bin", FileMode.Create, FileAccess.Write, FileShare.None);   //cria um novo ficheiro e coloca-o em modo escrita
            formatter.Serialize(stream, atendidos);  //coloca os dados que estao dentro do array e coloca no ficheiro aberto
            stream.Close();


            IFormatter formatter1 = new BinaryFormatter();
            Stream stream1 = new FileStream("TotalUtentes.bin", FileMode.Create, FileAccess.Write, FileShare.None);  
            formatter.Serialize(stream1, totalUtentes);
            stream1.Close();


            IFormatter formatter2 = new BinaryFormatter();
            Stream stream2 = new FileStream("AtendidosEnaoAtendidos.bin", FileMode.Create, FileAccess.Write, FileShare.None);
            formatter.Serialize(stream2, atendENAtend);
            stream2.Close();

            IFormatter formatter3 = new BinaryFormatter();
            Stream stream3 = new FileStream("Medicos.bin", FileMode.Create, FileAccess.Write, FileShare.None);
            formatter.Serialize(stream3, med);
            stream3.Close();


            IFormatter formatter4 = new BinaryFormatter();
            Stream stream4 = new FileStream("Enfermeiro.bin", FileMode.Create, FileAccess.Write, FileShare.None);
            formatter.Serialize(stream4, enf);
            stream4.Close();

            return "Guardado Com Sucesso";
        }

        /// <summary>
        /// Le os 5 ficheiros e adiciona-os a 5 arrays diferentes
        /// </summary>
        /// <returns>item1=Atendidos, item2=listaGeral, item3=posTriagem, item4=Medicos, item5=enfermeiros</returns>
        public Tuple<Utente[], Utente[], Utente[],Medico[],Enfermeiro[]> LeFicheiro() 
        {
            Utente[] atendidos = new Utente[50];
            Utente[] listaGeral = new Utente[300];
            Utente[] posTriagem = new Utente[50];
            Medico[] med = new Medico[50];
            Enfermeiro[] enf = new Enfermeiro[50];


            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream("Atendidos.bin", FileMode.Open, FileAccess.Read, FileShare.Read);  //abre o ficheiro com o nome apresentado, e coloca-o em modo de leitura
            atendidos = (Utente[])formatter.Deserialize(stream);  //copia os dados que estao no ficheiro e coloca-os em arrays de classes indicadas
            stream.Close();

            IFormatter formatter1 = new BinaryFormatter();
            Stream stream1 = new FileStream("TotalUtentes.bin", FileMode.Open, FileAccess.Read, FileShare.Read);
            listaGeral = (Utente[])formatter.Deserialize(stream1);
            stream1.Close();

            IFormatter formatter2 = new BinaryFormatter();
            Stream stream2 = new FileStream("AtendidosEnaoAtendidos.bin", FileMode.Open, FileAccess.Read, FileShare.Read);
            posTriagem = (Utente[])formatter.Deserialize(stream2);
            stream2.Close();

            IFormatter formatter3 = new BinaryFormatter();
            Stream stream3 = new FileStream("Medicos.bin", FileMode.Open, FileAccess.Read, FileShare.Read);
            med = (Medico[])formatter.Deserialize(stream3);
            stream3.Close();

            IFormatter formatter4 = new BinaryFormatter();
            Stream stream4 = new FileStream("Enfermeiro.bin", FileMode.Open, FileAccess.Read, FileShare.Read);
            enf = (Enfermeiro[])formatter.Deserialize(stream4);
            stream4.Close();

            return Tuple.Create(atendidos, listaGeral,posTriagem,med,enf);  //retorna ao main 5 arrays: 3 de utentes, 1 de medicos e 1 de enfermeiros
        }

        #endregion

    }
}
