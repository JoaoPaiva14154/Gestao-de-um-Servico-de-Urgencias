﻿/*      Trabalho Prático LP2
 *  |Gestão Urgência|
 * 
 *  José Paulo Antunes      a11582@alunos.ipca.pt
 *  João Paiva              a14154@alunos.ipca.pt
 *  
 *  IPCA 2019/2020
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace LP2_trabalho
{

    /// <summary>
    /// Classe que lida com os enfermeiros
    /// </summary>

    [Serializable]
    class Enfermeiro : FuncionarioMedico
    {
        #region ATRIB
        public string especialidade;
        int numEnfermeiro; //Numero
        bool naUrgencia = false;
        #endregion

        #region METODOS

        #region CONSTRUTORES
        // Métodos usados na criação de novos objectos

        /// <summary>
        /// Construtor de enfermeiro
        /// </summary>
        /// <param name="n">nome</param>
        /// <param name="p">Posicao</param>
        /// <param name="esp">especialidade</param>
        /// <param name="num">numero de enfermeiro</param>

        public Enfermeiro(string n, string p, string esp, int num) : base(n, p)
        {
            Nome = n;
            Posicao = p;
            especialidade = esp;
            numEnfermeiro = num;
        }
        /// <summary>
        /// Enfermeiro Default
        /// </summary>
        public Enfermeiro()
        {
            Nome = "";
            Posicao = "";
            especialidade = "";
        }

        #endregion

        #region PROPRIEDADES
        /// <summary>
        /// Especialidade
        /// </summary>
        public string Especialidade
        {
            get { return especialidade; }
            set { especialidade = value; }
        }

        /// <summary>
        /// Numero de Enfermeiro
        /// </summary>
        public int NumEnfermeiro
        {
            get { return numEnfermeiro; }
            set { numEnfermeiro = value; }
        }

        /// <summary>
        /// Situaçao urgencia
        /// </summary>
        public bool NaUrgencia
        {
            get { return naUrgencia; }
            set { naUrgencia = value; }
        }

        #endregion

       
        #endregion



    }
}
