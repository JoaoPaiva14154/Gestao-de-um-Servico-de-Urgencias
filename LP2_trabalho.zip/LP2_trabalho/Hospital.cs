﻿/*      Trabalho Prático LP2
 *  |Gestão Urgência|
 * 
 *  José Paulo Antunes      a11582@alunos.ipca.pt
 *  João Paiva              a14154@alunos.ipca.pt
 *  
 *  IPCA 2019/2020
 */

using System;
using System.Collections.Generic;
using System.Text;


namespace LP2_trabalho
{

    /// <summary>
    /// Classe que contém funções de gestão e listagem de médicos e enfermeiros
    /// </summary>

    class Hospital
    {
        #region ATRIB
        public Medico[] totMed=new Medico[50];
        public Enfermeiro[] totEnf = new Enfermeiro[100];

        #endregion


        #region METODOS

        /// <summary>
        /// Cria medico
        /// </summary>
        /// <param name="med">Array de Medicos</param>
        /// <returns>Um medico</returns>
        public Medico AdicionaMedico(Medico[] med)
        {
            Medico auxMe = new Medico();

            Console.WriteLine("Qual o nome do medico?");       
            string nome = Console.ReadLine();
            Console.WriteLine("Qual o numero de medico?");
            int aux1 = int.Parse(Console.ReadLine());

            for (int i = 0; i < med.Length; i++)
            {
                if (med[i] != null)
                {
                    if (med[i].NumMedico == aux1)  //verifica se o medico ja existe no sistema
                    {
                        Console.WriteLine("Numero de medico ja existente.");
                        return null;
                    }
                }
            }
            
            Console.WriteLine("Qual a especialidade?");
            string aux2 = Console.ReadLine();

           auxMe= new Medico(nome, "medico", aux2, aux1); //cria novo medico

            return auxMe;

        }
        /// <summary>
        /// Cria enfermeiros
        /// </summary>
        /// <param name="enf">Array de enfermeiros</param>
        /// <returns>enfermeiro</returns>
        public Enfermeiro AdicionaEnfermeiro(Enfermeiro [] enf)
        {
            Enfermeiro auxEnf = new Enfermeiro();

            Console.WriteLine("Qual o nome do enfermeiro?");
            string nome = Console.ReadLine();
            Console.WriteLine("Qual o numero de enfermeiro?");
            int aux1 = int.Parse(Console.ReadLine());

            for (int i = 0; i < enf.Length; i++)
            {
                if (enf[i] != null) 
                {
                    if (enf[i].NumEnfermeiro == aux1)  //verifica se o enfermeiro ja existe
                    {
                        Console.WriteLine("Numero de enfermeiro ja existente.");
                        return null;
                    }
                }
            }

            Console.WriteLine("Qual a especialidade?");
            string aux2 = Console.ReadLine();

            auxEnf = new Enfermeiro(nome, "enfermeiro", aux2, aux1);  //cria novo enfermeiro

            return auxEnf;
        }


        /// <summary>
        /// Mostra funcionarios medicos (medicos)
        /// </summary>
        /// <param name="med">Array de medicos</param>
        public void MostraFuncionarioMedico(Medico[] med)
        {
            int cont = 0;
            for (int i = 0; i < med.Length; i++)
            {
                if (med[i] != null)
                {
                    Console.WriteLine("Med {0} ", i+1);
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("Nome: {0}", med[i].Nome);
                    Console.WriteLine("Especialidade: {0}", med[i].Especialidade);
                    Console.WriteLine("Encontra-se na urgencia? : {0}", med[i].NaUrgencia);                   
                    Console.WriteLine("Numero de medico : {0}", med[i].NumMedico);
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("--__--__--__--__--__--__--__--");

                    cont++;
                }
              
            }
            if (cont ==0)
            {
                Console.WriteLine("Não ha medicos no sistema.");
            }


        }
        /// <summary>
        /// Mostra funcionarios medicos (enfermeiros)
        /// </summary>
        /// <param name="enf">Array de enf</param>
        public void MostraFuncionarioMedico(Enfermeiro[] enf)
        {
            int cont = 0;
            for (int i = 0; i < enf.Length; i++)
            {
                if (enf[i] != null)
                {
                    Console.WriteLine("Enfermeiro {0} ", i + 1);
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("Nome: {0}", enf[i].Nome);
                    Console.WriteLine("Especialidade: {0}", enf[i].Especialidade);
                    Console.WriteLine("Encontra-se na urgencia? : {0}", enf[i].NaUrgencia);
                    Console.WriteLine("Numero de enfermeiro : {0}", enf[i].NumEnfermeiro);
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("--__--__--__--__--__--__--__--");

                    cont++;
                }
               
            }
            if (cont == 0)
            {
                Console.WriteLine("Não ha enfermeiros no sistema.");
            }

        }

        #endregion

    }
}
