﻿/*      Trabalho Prático LP2
 *  |Gestão Urgência|
 * 
 *  José Paulo Antunes      a11582@alunos.ipca.pt
 *  João Paiva              a14154@alunos.ipca.pt
 *  
 *  IPCA 2019/2020
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace LP2_trabalho
{

    /// <summary>
    /// Classe que lida com os medicos
    /// </summary>

    [Serializable]
    class Medico : FuncionarioMedico
    {
        #region ATRIB
        public string especialidade;
        int numMedico;
        bool naUrgencia = false;
        #endregion


        #region METODOS

        #region CONSTRUTORES
        //Métodos usados na criação de novos objectos

            /// <summary>
            /// Construtor de medico
            /// </summary>
            /// <param name="n">nome</param>
            /// <param name="p">Posicao</param>
            /// <param name="esp">especialidade</param>
            /// <param name="num">numero de medico</param>
        public Medico(string n, string p,string esp,int num) : base (n,p)
        {
            Nome = n;
            Posicao = p;
            especialidade = esp;
            numMedico = num;
            
        }
        /// <summary>
        /// Medico Default
        /// </summary>
        public Medico()
        {
            Nome = "";
            Posicao = "";
            especialidade = "";
            
        }

        #endregion

        #region PROPRIEDADES
        /// <summary>
        /// Especialidade
        /// </summary>
        public string Especialidade
        {
            get { return especialidade ; }
            set { especialidade = value; }
        }

        /// <summary>
        /// Numero de medico
        /// </summary>
        public int NumMedico
        {
            get { return numMedico; }
            set { numMedico = value; }
        }
        /// <summary>
        /// Bool urgencia
        /// </summary>
        public bool NaUrgencia
        {
            get { return naUrgencia; }
            set { naUrgencia = value; }
        }

        #endregion

        /// <summary>
        /// Metodo para passar receitas, serve para enviar todos os medicamentos necessarios
        /// </summary>
        /// <param name="medico">Medico</param>
        /// <param name="utente">Utente</param>
        /// <returns></returns>
        public String[] PassarReceita(Medico medico, Utente utente)
        {
            Console.WriteLine("Quantos Medicamentos? ");
            int b = int.Parse(Console.ReadLine());
            string[] temp = new string[b];

            for (int i = 0; i <= b; i++)
            {
                Console.WriteLine("Nome do {1} Medicamento ", i + 1);
                temp[i] = Console.ReadLine();
            }
          
            return temp; 
        }

        #endregion

    }
}
