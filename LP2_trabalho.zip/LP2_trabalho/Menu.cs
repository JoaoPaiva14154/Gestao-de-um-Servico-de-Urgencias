﻿/*      Trabalho Prático LP2
 *  |Gestão Urgência|
 * 
 *  José Paulo Antunes      a11582@alunos.ipca.pt
 *  João Paiva              a14154@alunos.ipca.pt
 *  
 *  IPCA 2019/2020
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Linq;
using System.Collections;

namespace LP2_trabalho
{

    /// <summary>
    /// Classe que contém o menu inicial
    /// </summary>

    class Menu
    {
        public void Menux()
        {
            #region ESTADO
            string escolha;
            string auxstring;
            int i = 0, w = 0;
            int totMed = 0, totEnf = 0;
            int totMedUrg = 0,totEnfUrg = 0;
            string aux;

            #region INSTANCIAS DE CLASSES
            Urgencia auxUrg = new Urgencia(); 
            Utente auxU = new Utente();
            Auxiliar auxA = new Auxiliar();
            Data auxDat = new Data();
            Hospital auxHosp = new Hospital();
            #endregion


            Utente[] novU = new Utente[50];             // array de utentes geral
            Utente[] urgU = new Utente[50];             // array de utentes pos triagem
            Medico[] novMed = new Medico[50];           // array de novo medico
            Enfermeiro[] novEnf = new Enfermeiro[50];   // array de novo enfermeiro
            Medico[] medUrg = new Medico[50];           // array de medico de urgencia
            Enfermeiro[] enfUrg = new Enfermeiro[50];   // array de enfermerio de urgencia
            Utente[] listaEspera = new Utente[50];      // array de novos utentes para triagem
            Utente[] atendidos = new Utente[100];       // array de utentes atendidos de urgencia
            Utente[] utentAuxiliar = new Utente[30];    // array auxiliar
            Utente[] listaGeral = new Utente[200];      // array de utentes geral para incluir dados vindos de ficheiros e utentes gerais adicionados no decorrer o programa

            #endregion

            do
            {
                Console.WriteLine("Hospital\n");
                Console.WriteLine("___----____-----_____-----____----");
                Console.WriteLine("___----____-----_____-----____----");
                Console.WriteLine("___----____-----_____-----____----");
                Console.WriteLine("A - Adicionar utente");
                Console.WriteLine("B - Triagem Utente");
                Console.WriteLine("C - Urgencia Utente");
                Console.WriteLine("D - Adicionar Funcionario Medico");
                Console.WriteLine("E - Adicionar Funcionario Medico ao serviço de urgencia");
                Console.WriteLine("U - Mostra Utentes");
                Console.WriteLine("F - Mostra Funcionarios medicos");
                Console.WriteLine("L - Load aos ficheiros locais");
                Console.WriteLine("G - Guardar os dados em ficheiro");
                Console.WriteLine("S - Sair\n");
                Console.WriteLine("Escolha (A,B,C,D,E,U,F,L,G ou S):");

                escolha = Console.ReadLine();

                switch (escolha)
                {
                    case "A": // adiciona Utentes

                        listaEspera[i] = auxUrg.AdicionaUtente(listaEspera);
                        novU[i] = listaEspera[i];
                        i++;

                        break;

                    case "B": // triagem utentes

                        Console.WriteLine("Escreva o seu numero de medico:");
                        int numaux = int.Parse(Console.ReadLine());
                        int numaux1 = 0; // contador auxiliar para auxiliar na existencia ou não de medicos
                        for (int x = 0; x < novMed.Length; x++)  // percorrer o array de medicos, saber se o numero de medico está no sistema, So com medicos se pode efectuar a triagem e a urgencia
                        {
                            if (novMed[x] != null)
                            {
                                if (novMed[x].NumMedico == numaux)
                                {
                                    Console.WriteLine("Bem vindo Dr {0}", novMed[x].Nome);

                                    Console.WriteLine("Escreva ''proximo'' ou ''next'' quando estiver disponivel...");
                                    urgU[w] = auxUrg.Triagem(listaEspera);
                                    listaEspera = listaEspera.Skip(1).ToArray();   //skip no array para avançar na lista de espera

                                    numaux1++;
                                }
                            }
                            numaux1++;  
                        }
                        if (numaux1 ==0)  // se não entrar no ciclo for inicial, significa que o contador vai ser igual ao inicial (0) se isso acontecer é porque não ha medicos adicionados
                        {
                            Console.WriteLine("Não existe nenhum medico para triagem ou numero de medico esta errado.");
                        }
                       
                         w++;

                        break;

                    case "C":  // urgencia de utentes

                        Console.WriteLine("Escreva o seu numero de medico:");
                        int numaux2 = int.Parse(Console.ReadLine());
                        int numaux3 = 0; // auxiliar para saber se existe medicos ou não no sistema
                        for (int x = 0; x < medUrg.Length; x++)
                        {
                            if (medUrg[x] != null)
                            {
                                if (medUrg[x].NumMedico == numaux2)
                                {
                                    Console.WriteLine("Bem vindo, Dr. {0}", medUrg[x].Nome);

                                    if (urgU[0] == null)  // aqui so verificamos o primeiro endereço do array urgU, pois neste array não ha skips, logo um Null no primeiro endereço do array significa que o array estará vazio
                                    {
                                        Console.WriteLine("Não existem Utentes para urgencia.");
                                    }
                                    else
                                    {
                                        Utente[] auxaux = new Utente[w]; // criar um novo array para conseguir organizar por prioridade
                                        auxaux = auxA.NovArr(urgU, w); // transfere os utentes do array geral para um array  com um numero igual ao de utentes

                                        auxaux = auxA.OrgUtentes(auxaux);  // ordena os utentes

                                        Console.WriteLine("Escreva proximo, ou next quando estiver disponivel");
                                        auxaux = auxUrg.UrgenciaGeral(auxaux); // chama o metodo de urgencia geral

                                        atendidos = auxA.NovArr(auxaux, atendidos); // chama o metodo para copiar arrays
                                        
                                        numaux3++; // incrementar o auxiliar de existencia de medicos
                                    }
                                }
                            }
                            numaux3++;
                        }
                        if (numaux3 == 0)
                        {
                            Console.WriteLine("Não existe nenhum medico para triagem ou Numero medico errado");
                        }

                        break;

                    case "D": // adiciona funcionario medico

                        Console.WriteLine("Qual a posição do Funcionario medico?");
                        Console.WriteLine("medico ou enfermeiro ?");
                        aux = Console.ReadLine();  // o utilizador insere a posiçao do funcionario medico
                        if(aux == "medico" || aux == "med")   
                        {
                            novMed[totMed] = auxHosp.AdicionaMedico(novMed);  // utiliza a função de adicionar medico 
                            if (novMed[totMed] != null)
                            {
                                totMed++; // se for adicionado um medico, ou seja, se a função não returnar null, este numero de medicos vai incrementando
                            }
                        }
                        else if (aux == "enfermeiro" || aux == "enf")
                        {
                            novEnf[totEnf] = auxHosp.AdicionaEnfermeiro(novEnf);  // utiliza a função de adicionar enfermeiro 
                            if (novEnf[totEnf] != null)
                            {
                                totEnf++; // aumenta se for adicionado um enfermeiro
                            }

                        }
                        else
                        {
                            Console.WriteLine("Escolha não aceite"); // resposta invalida
                        }

                        break;

                    case "E": // adiciona medico ou enfermeiro ja existente a urgencia

                        Console.WriteLine("Pretende adicionar medico ou enfermeiro?");
                        aux = Console.ReadLine();
                        if(aux == "medico" || aux == "med")
                        {
                            medUrg[totMedUrg] = auxUrg.DeServicoNaUrgencia(aux,novMed); // utiliza a função de adicionar medico à urgencia

                            if (medUrg[totMedUrg] != null)
                            {
                                totMedUrg++;
                            }
                        }
                        else if (aux == "enfermeiro" || aux == "enf")
                        {
                            enfUrg[totEnfUrg] = auxUrg.DeServicoNaUrgencia(aux, novEnf); // utiliza a função de adicionar enfermeiro à urgencia
                            if (enfUrg[totEnfUrg] != null)
                            {
                                totEnfUrg++;
                            }                         
                        }
                        else
                        {
                            Console.WriteLine("Escolha não aceite.");
                        }

                        break;
                  
                    case "U": // mostra utentes

                        Console.WriteLine("Quais os utentes que quer observar?");
                        Console.WriteLine("---------");
                        Console.WriteLine("Pressione um numero");
                        Console.WriteLine("1 - Utentes geral ");
                        Console.WriteLine("2 - Utentes pos Triagem não atendidos");
                        Console.WriteLine("3 - Utentes atendidos");
                        int numA = int.Parse(Console.ReadLine()); // ler resposta

                        if (numA ==1)
                        {
                            if (listaGeral[0] != null)
                            {
                                auxUrg.MostraUtenteG(listaEspera); // chama funçao mostrar utentes geral
                            }
                            else
                            {
                                Console.WriteLine("---------");
                                Console.WriteLine("Não ha utentes no sistema");
                            }
                        }
                        else if (numA == 2)
                        {
                            if (urgU[0] != null)
                            {
                                auxUrg.MostraUtentePosT(urgU); // chama funçao mostrar utentes nao atendidos
                            }
                            else
                            {
                                Console.WriteLine("---------");
                                Console.WriteLine("Não existem utentes pos triagem nao atendidos.");
                            }
                        }
                        else if (numA == 3)
                        {
                            if (atendidos[0] != null)
                            {
                                auxUrg.MostraUtenteAtend(atendidos); ; // chama funçao mostrar utentes atendidos
                            }
                            else
                            {
                                Console.WriteLine("---------");
                                Console.WriteLine("Não existem utentes que foram atendidos.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("---------");
                            Console.WriteLine("{0} é uma escolha invalida.", numA);
                        }

                        break;

                    case "F": // mostra funcionarios medicos

                        Console.WriteLine("Deseja consultar os medicos ou Enfermeiros?");
                        string kek = Console.ReadLine(); // ler resposta
                        if (kek=="med"||kek == "medico")
                        {
                            auxHosp.MostraFuncionarioMedico(novMed); // chama funçao mostrar funcionarios medicos (medicos)
                        }
                        else if (kek == "enf" || kek == "enfermeiro")
                        {
                            auxHosp.MostraFuncionarioMedico(novEnf); // chama funçao mostrar funcionarios medicos (enfermeiros)
                        }

                        else
                        {
                            Console.WriteLine("'{0}' não é uma escolha certa.", kek);         
                        }

                        break;


                    case "L": // carrega os dados dos ficheiros

                        var arrays = auxDat.LeFicheiro(); // var arrays contem 3 arrays, item1, 2 e 3, sendo estes atendidos, geral e postriagem, por esta ordem

                        // coloca os atendidos no array dos atendidos
                        atendidos = auxA.NovArr(arrays.Item1, atendidos); // adiciona os atendidos do ficheiro ao array de atendidos do programa antes de gravar


                        // coloca utentes em utentes atendido ou não atendidos
                        if (arrays.Item3 != null)
                        {
                            utentAuxiliar = auxUrg.AindaNaoAtendidos(arrays.Item3); // filtra os utentes do array com atendidos e não atendidos e coloca os não atendidos num array
                        }
                        urgU = auxA.NovArr(utentAuxiliar, urgU); // coloca os não atendidos no array "Pos triagem" para serem atendidos

                        // coloca utentes totais num array geral lista geral de utentes
                        listaGeral = auxA.NovArr(arrays.Item2, listaEspera); // junta os 2 arrays num unico array de maior dimensão

                        // coloca medicos no array de medicos
                        novMed = auxA.NovArr(arrays.Item4, novMed); // adiciona os medicos no novo array                                            
                        for (int p = 0; p < novMed.Length; p++) // muda o numero do contador de array para ao adicionar novo medico não dar over-write no medico loaded
                        {
                            if (novMed[p] != null)
                            {
                                totMed++;
                            }
                        }

                        // coloca enfermeiros no array de enfermeiros
                        novEnf = auxA.NovArr(arrays.Item5, novEnf);
                        for (int p = 0; p < novEnf.Length; p++) // muda o numero do contador de array para ao adicionar novo medico não dar over-write no medico loaded
                        {
                            if (novEnf[p] != null)
                            {
                                totEnf++;
                            }
                        }

                        break;

                    case "G":

                        auxstring = auxDat.GuardaEmBin(atendidos, novU, urgU, novMed, novEnf); // guarda os atendidos em ficheiro binario

                        break;

                    default: // caso default (letra nao reconhecida)
                        Console.WriteLine("{0} : escolha invalida.", escolha);
                        break;

                    case "S": // caso sair
                        Console.WriteLine("___---____---___");
                        System.Environment.Exit(1);
                        break;
                }

                Console.Write("Carregar em Enter para continuar...\n");
                Console.ReadLine();
                Console.WriteLine();
            } while (escolha != "S");
        }
    }
}
