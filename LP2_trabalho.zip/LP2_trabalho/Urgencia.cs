﻿/*      Trabalho Prático LP2
 *  |Gestão Urgência|
 * 
 *  José Paulo Antunes      a11582@alunos.ipca.pt
 *  João Paiva              a14154@alunos.ipca.pt
 *  
 *  IPCA 2019/2020
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace LP2_trabalho
{

    /// <summary>
    /// Classe que contém funções para gerir a urgencia
    /// </summary>

    class Urgencia : Hospital
    {
        #region ATRIB
        int numeroDeUtentes = 0;
        Utente[] totUtente = new Utente[50];
        Medico[] medDeUrgencia = new Medico[10];
        Enfermeiro[] enfDeUrgencia = new Enfermeiro[30];

        Utente[] utentUrg = new Utente[50];  // array de utentes para a urgencia
        Utente[] utentTria = new Utente[50]; // array de utentes para a triagem
        #endregion

        #region METODOS
        /// <summary>
        /// Adiciona utente
        /// </summary>
        /// <returns></returns>
        public Utente AdicionaUtente(Utente[] ut)
        {
            Console.WriteLine("Numero de Utente :");
            int numUtente = int.Parse(Console.ReadLine());

            for (int i = 0; i < ut.Length; i++)
            {
                if (ut[i] != null)
                {
                    if (ut[i].NumeroCartao == numUtente)
                    {
                        Console.WriteLine("Numero de Utente ja existente");
                    }
                }
            }
            Console.WriteLine("Nome do Utente");
            string nome = Console.ReadLine();
            Console.WriteLine("Região do utente");
            string regiao = Console.ReadLine();
            Console.WriteLine("Sexo do utente");
            string sexo = Console.ReadLine();
            Console.WriteLine("Data de Nascimento ");
            Console.WriteLine("ano");
            int aux1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Mes(numero)");
            int aux2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Dia");
            int aux3 = int.Parse(Console.ReadLine());
            DateTime dataNascimento = new DateTime(aux1, aux2, aux3);

            totUtente[numeroDeUtentes] = new Utente(nome, regiao, sexo, dataNascimento, numUtente);
            totUtente[numeroDeUtentes].Idade = (int.Parse(DateTime.Now.ToString("yyyyMMdd")) - int.Parse(dataNascimento.ToString("yyyyMMdd"))) / 10000;

            return totUtente[numeroDeUtentes];
        }
        /// <summary>
        /// Adiciona medico ao servico de urgencia
        /// </summary>
        /// <param name="posicao">Med ou enf</param>
        /// <param name="med">Array de Med</param>
        /// <returns></returns>
        public Medico DeServicoNaUrgencia(string posicao, Medico[] med)
        {
            int cont = 0;

            if (posicao == "medico" || posicao == "med")
            {
                Medico aux1 = new Medico();

                Console.WriteLine("Qual o numero do medico que vai entrar na urgencia?");
                int aux = int.Parse(Console.ReadLine());

                for (int i = 0; i < med.Length; i++)
                {
                    if (med[i] != null)
                    {

                        if (aux == med[i].NumMedico)
                        {
                            med[i].NaUrgencia = true;

                            aux1 = med[i];

                            Console.WriteLine("Medico numero: {0} Nome: {1} adicionado com sucesso a urgencia", aux1.NumMedico,aux1.Nome);
                           
                            return aux1;
                        }
                    }
                }

                if (cont == 0)
                {
                    Console.WriteLine("Não ha nenhum medico com esse numero");
                    return null;
                }
            }
            return null;
        }
        /// <summary>
        /// Adiciona enfermeiro ao servico de urgencia
        /// </summary>
        /// <param name="posicao">Enf ou Med</param>
        /// <param name="enf">Array de enf</param>
        /// <returns></returns>
        public Enfermeiro DeServicoNaUrgencia(string posicao, Enfermeiro[] enf)
        {
            int cont = 0;

            if (posicao == "enfermeiro" || posicao == "enf")
            {
                Enfermeiro aux1 = new Enfermeiro();

                Console.WriteLine("Qual o numero do enf que vai entrar na urgencia?");
                int aux = int.Parse(Console.ReadLine());

                for (int i = 0; i < enf.Length; i++)
                {
                    if (enf[i] != null)
                    {

                        if (aux == enf[i].NumEnfermeiro)
                        {
                            enf[i].NaUrgencia = true;

                            aux1 = enf[i];

                            Console.WriteLine("Enfermeiro numero: {0} Nome: {1} adicionado com sucesso a urgencia", aux1.NumEnfermeiro, aux1.Nome);

                            return aux1;
                        }
                    }
                }

                if (cont == 0)
                {
                    Console.WriteLine("Não ha nenhum medico ou enf com esse numero");
                    return null;
                }
            }
            return null;       
        }

        /// <summary>
        /// Triagem do utente
        /// </summary>
        /// <param name="utentTria">Array de utentes</param>
        /// <returns></returns>
        public Utente Triagem(Utente[] utentTria)
        {
          Utente aux1;
         
          int aux2 = 0;
          string aux =  Console.ReadLine();

            if (aux == "next" || aux == "proximo")
            {
                if (utentTria[aux2] != null) 
                {
                    Console.WriteLine("Dados do Utente");
                    aux1 = utentTria[aux2];
                    Console.WriteLine("___----____----____");
                    Console.WriteLine("___----____----____");
                    Console.WriteLine("Nome: {0}",aux1.Nome);
                    Console.WriteLine("Idade: {0}", aux1.Idade);
                    Console.WriteLine("Sexo: {0}", aux1.Sexo);
                    Console.WriteLine("Região: {0}", aux1.Regiao);
                    Console.WriteLine("___----____----____");
                    Console.WriteLine("___----____----____");

                    Console.WriteLine("Qual a pulseira do utente?");
                    string pulseira = Console.ReadLine();
                    aux1.Estado = pulseira;
                   
                    if(pulseira=="vermelha"|| pulseira== "vermelho" || pulseira == "red")
                    {
                        aux1.Prioridade = 1;
                    }
                    else if (pulseira == "amarela" || pulseira == "amarelo" || pulseira == "yellow")
                    {
                        aux1.Prioridade = 2;
                    }
                  else  if (pulseira == "verde" || pulseira =="green")
                    {
                        aux1.Prioridade = 3;
                    }

                    else { aux1.Prioridade = 5; }

                    aux1.DataDeEntrada = DateTime.Now;
                    aux1.Atendido = false; // os utentes que passam pela triagem mudam o seu estado de atendido para falso, so são atendidos dentro do serviço de urgencia

                    return aux1;
                }
               if (utentTria[aux2] == null)
                {
                    Console.WriteLine("Não ha novos utentes para triagem");
                    return null;
                }                

            }
            return null;
        }
        /// <summary>
        /// Funcao para atender utentes
        /// </summary>
        /// <param name="utentUrg">Utente da urgencia</param>
        /// <returns></returns>
        public Utente[] UrgenciaGeral(Utente[] utentUrg)
        {
            Utente aux1;
            
            string aux = Console.ReadLine();
            string aux3;
            int aux2=0;

            if (aux == "next" || aux == "proximo")
            {

                while (utentUrg[aux2].Atendido == true) // percorrer o array a procura de utentes que ainda não foram atendidos
                {
                    aux2++; // incrementar
                    if (utentUrg[aux2] == null)
                    {
                        Console.WriteLine("Não tem utentes novos para serem atendidos.");
                        return utentUrg;
                    }
                } 
                if (utentUrg[aux2] != null)
                {
                                aux1 = utentUrg[aux2];
                                Console.WriteLine("Nome: {0}", aux1.Nome);
                                Console.WriteLine("Idade:{0}", aux1.Idade);
                                Console.WriteLine("Sexo: {0}", aux1.Sexo);
                                Console.WriteLine("Região: {0}", aux1.Regiao);
                                Console.WriteLine("Pulseira: {0}", aux1.Estado);
                                Console.WriteLine("___----____----____");
                                Console.WriteLine("___----____----____");
                                Console.WriteLine("Deseja adicionar alguma observacao?");

                                utentUrg[aux2].DatadeAtendimento = DateTime.Now;
                                aux3 = Console.ReadLine();
                                utentUrg[aux2].Observacoes = aux3; // adiciona observaçoes
                                utentUrg[aux2].Atendido = true;

                                utentUrg[aux2].TempoEspera = (utentUrg[aux2].DatadeAtendimento - utentUrg[aux2].DataDeEntrada).TotalMinutes; // calcula o tempo que demorou a ser atendido
                                Console.WriteLine("Tempo de espera foi de {0}.", Math.Round(utentUrg[aux2].TempoEspera, 2).ToString());

                                aux2++; 
                }              
            }
            return utentUrg;
        }

        /// <summary>
        /// Coloca num array os utentes não atendidos
        /// </summary>
        /// <param name="ut">Array de utentes</param>
        /// <returns></returns>
        public Utente[] AindaNaoAtendidos(Utente[] ut)
        {
            Utente[] aux = new Utente[50];
            int k = 0;

            for (int i = 0; i < ut.Length; i++)
            {
                if (ut[i] != null)
                {
                    if (ut[i].Atendido == false)
                    {
                        aux[k] = ut[i];
                        k++;
                    }
                }
            }            
            return aux;
        }

        /// <summary>
        /// Apresenta na consola os dados do utente
        /// </summary>
        /// <param name="ut">Array de Utentes</param>
        public void MostraUtenteG(Utente[] ut)
        {
            int cont = 0;
            for (int i = 0; i <ut.Length; i++)
            {
                if (ut[i] != null)
                {
                    Console.WriteLine("Utente {0} ", i+1);
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("Nome: {0}", ut[i].Nome);
                    Console.WriteLine("Idade: {0}", ut[i].Idade);
                    Console.WriteLine("Regiao: {0}", ut[i].Regiao);
                    Console.WriteLine("Regiao: {0}", ut[i].Sexo);
                    Console.WriteLine("Num Utente : {0}", ut[i].NumeroCartao);
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    
                    cont++;                
                }                
            }
            if (cont == 0)
            {
                Console.WriteLine("Não ha Utentes");
            }          
        }
        /// <summary>
        /// Mostra utentes nao atendidos (pos triagem) 
        /// </summary>
        /// <param name="ut">Array utentes</param>
        public void MostraUtentePosT(Utente[] ut)
        {
            int cont = 0;
            for (int i = 0; i < ut.Length; i++)
            {
                if (ut[i] != null)
                {
                    Console.WriteLine("Utente {0} ", i+1);
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("Nome: {0}", ut[i].Nome);
                    Console.WriteLine("Idade: {0}", ut[i].Idade);
                    Console.WriteLine("Regiao: {0}", ut[i].Regiao);
                    Console.WriteLine("Regiao: {0}", ut[i].Sexo);
                    Console.WriteLine("Num Utente : {0}", ut[i].NumeroCartao);
                    Console.WriteLine("Data Entrada: {0}", ut[i].DataDeEntrada.ToString("HH:mm  dd-MM-yyyy"));
                    Console.WriteLine("Pulseira : {0}", ut[i].Estado);
                    if (ut[i].Atendido == true)
                    {
                        Console.WriteLine("Atendido as : {0} ",ut[i].DatadeAtendimento.ToString("HH:mm dd-MM-yyyy"));
                        Console.WriteLine("Tempo de espera foi de : {0,-2} ", ut[i].TempoEspera.ToString());
                    }
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("--__--__--__--__--__--__--__--");

                    cont++;                
                }
                if (cont == 0)
                {
                    Console.WriteLine("Não ha Utentes");
                }
            }
        } 
        /// <summary>
        /// Mostra utentes atendidos
        /// </summary>
        /// <param name="ut">Array de utentes</param>
        public void MostraUtenteAtend(Utente[] ut)
        {
            int cont = 0;
            for (int i = 0; i < ut.Length; i++)
            {
                if (ut[i] != null)
                {
                    Console.WriteLine("Utente {0} ", i+1);
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("Nome: {0}", ut[i].Nome);
                    Console.WriteLine("Idade: {0}", ut[i].Idade);
                    Console.WriteLine("Regiao: {0}", ut[i].Regiao);
                    Console.WriteLine("Regiao: {0}", ut[i].Sexo);
                    Console.WriteLine("Num Utente : {0}", ut[i].NumeroCartao);
                    Console.WriteLine("Data Entrada: {0}", ut[i].DataDeEntrada.ToString("HH:mm  dd-MM-yyyy"));
                    Console.WriteLine("Pulseira : {0}", ut[i].Estado);                   
                    Console.WriteLine("Atendido as : {0} ", ut[i].DatadeAtendimento.ToString("HH:mm dd-MM-yyyy"));
                    Console.WriteLine("Tempo de espera foi de : {0} ", Math.Round(ut[i].TempoEspera,2).ToString());
                    Console.WriteLine(".....");
                    Console.WriteLine("{0}",ut[i].Observacoes);
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("--__--__--__--__--__--__--__--");
                    Console.WriteLine("--__--__--__--__--__--__--__--");

                    cont++;                
                }
            }
            if (cont == 0)
            {
                Console.WriteLine("Não ha Utentes");
            }
        }
        #endregion
    }
}
