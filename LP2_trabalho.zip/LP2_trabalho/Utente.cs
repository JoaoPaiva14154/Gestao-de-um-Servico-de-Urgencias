﻿/*      Trabalho Prático LP2
 *  |Gestão Urgência|
 * 
 *  José Paulo Antunes      a11582@alunos.ipca.pt
 *  João Paiva              a14154@alunos.ipca.pt
 *  
 *  IPCA 2019/2020
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace LP2_trabalho
{

    /// <summary>
    /// Classe que lida com os utentes
    /// </summary>

    [Serializable]  //serve para permitir a gravação em binario
    class Utente
    {
        #region ESTADO
        string nome;
        string estado; // so no fim da triagem
        int prioridade;
        double tempoEspera;
        string regiao;
        string sexo;
        int numeroCartao;
        bool atendido;
        string observacoes;
        int idade;
        DateTime dataNasc;        
        DateTime dataDeEntrada;
        DateTime dataDeAtendimento;
        #endregion

        #region METODOS

        #region CONSTRUTORES
        // Métodos usados na criação de novos objectos

        /// <summary>
        /// Construtor com valores por defeito/omissão
        /// </summary>
        public Utente()
        {
            nome = "";
            estado = "";
            regiao = "";
            sexo = "";
        }

        /// <summary>
        /// Construtor com dados vindos do exterior
        /// </summary>
        /// <param name="n">Nome da Pessoa</param>
        /// <param name="r">Regiao da Pessoa</param>
        /// <param name="s">Sexo da Pessoa</param>
        /// <param name="dataNascim">Data nascimento</param>
        /// <param name="cc">Numero cartao de utente (unico)</param>

        public Utente(string n, string r, string s,DateTime dataNascim,int cc)
        {            
            nome = n;            
            regiao = r;
            sexo = s;
            dataNasc = dataNascim;
            idade = (int.Parse(DateTime.Now.ToString("yyyyMMdd")) - int.Parse(dataNascim.ToString("yyyyMMdd"))) /10000;
            numeroCartao = cc;
        }

        #endregion

        #region PROPRIEDADES
        //Métodos usados para manipular atributos do Estado


        /// <summary>
        /// Manipula o atributo "nome"
        /// (string)
        /// </summary>
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        /// <summary>
        /// Manupula o atributo "atendido"
        /// (bool)
        /// </summary>
        public bool Atendido
        {
            get { return atendido; }
            set { atendido = value; }
        }

        /// <summary>
        /// Manupula o atributo "estado"
        /// (string)
        /// [Vermelho/amarelo/verde]
        /// </summary>
        public string Estado 
        {
            get { return estado; }
            set { estado = value; }
        }

        /// <summary>
        /// Manipula o atributo "regiao"
        /// (string)
        /// </summary>
        public string Regiao
        {
            get { return regiao; }
            set { regiao = value; }
        }

        /// <summary>
        /// Manipula o atributo "sexo"
        /// (string)
        /// </summary>
        public string Sexo
        {
            get { return sexo; }
            set { sexo = value; }
        }

        /// <summary>
        /// Data de nascimento
        /// (datetime)
        /// </summary>
        public DateTime DataDeNascimento
        {
            get { return dataNasc; }
            set
            {
                DateTime aux;
                if (DateTime.TryParse(value.ToString(), out aux) == true)
                {
                    dataNasc = value;
                }
            }
        }

        /// <summary>
        /// Data de entrada
        /// (datetime)
        /// </summary>
        public DateTime DataDeEntrada
        {
            get { return dataDeEntrada; }
            set
            {
                DateTime aux;
                if (DateTime.TryParse(value.ToString(), out aux) == true)
                {
                    dataDeEntrada = value;
                }
            }
        }
        /// <summary>
        /// Data de atendimento
        /// (datetime)
        /// </summary>
        public DateTime DatadeAtendimento
        {
            get { return dataDeAtendimento; }
            set
            {
                DateTime aux;
                if (DateTime.TryParse(value.ToString(), out aux) == true)
                {
                    dataDeAtendimento = value;
                }
            }
        }

        /// <summary>
        /// Idade do utente
        /// (int)
        /// </summary>
        public int Idade 
        {
            get { return idade; }
            set 
            {
                idade = value;
            }
        }
        /// <summary>
        /// Prioridade atendimento
        /// (int)
        /// </summary>
        public int Prioridade
        {
            get { return prioridade; }
            set { prioridade = value; }
        }

        /// <summary>
        /// Observacoes do atendimento
        /// (varios)
        /// </summary>
        public string Observacoes
        {
            get { return observacoes; }
            set { observacoes = value; }
        }
        /// <summary>
        /// Tempo de espera
        /// (double)
        /// </summary>
        public double TempoEspera
        {
            get { return tempoEspera; }
            set { tempoEspera = value; }
        }
        /// <summary>
        /// Numero de cartao
        /// (int)
        /// </summary>
        public int NumeroCartao
        {
            get { return numeroCartao; }
            set { numeroCartao = value; }
        }

        #endregion

        #endregion

        #region OVERRIDES
        public override string ToString()
        {
            return " Nome: " + nome + " Estado: " + estado;
        }
        #endregion

        /// <summary>
        /// Destrutor
        /// </summary>
        ~Utente()
        {

        }
    }
}
