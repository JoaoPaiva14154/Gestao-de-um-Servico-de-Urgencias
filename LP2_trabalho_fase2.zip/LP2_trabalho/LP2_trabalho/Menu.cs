﻿/*      Trabalho Prático LP2
 *  |Gestão Urgência|
 * 
 *  José Paulo Antunes      a11582@alunos.ipca.pt
 *  João Paiva              a14154@alunos.ipca.pt
 *  
 *  IPCA 2019/2020
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace LP2_trabalho
{
    class Menu
    {
       public void Menux()
        {
            string escolha;
            Urgencia auxUrg = new Urgencia();
            Utente auxU = new Utente();
            LinkedListNode<Utente> nov=new LinkedListNode<Utente>(null);
            Hospital auxHosp = new Hospital();
            string aux;

            do
            {
                
                Console.WriteLine("Hospital\n");
                Console.WriteLine("___----____-----_____-----____----");
                Console.WriteLine("___----____-----_____-----____----");
                Console.WriteLine("___----____-----_____-----____----");
                Console.WriteLine("A - Adicionar utente.");
                Console.WriteLine("B - Triagem utente.");
                Console.WriteLine("C - Ver urgencias.");
                Console.WriteLine("D - Adicionar funcionario medico.");
                Console.WriteLine("E - Mover funcionario medico para serviço de urgencia.");
                Console.WriteLine("S - Sair.\n");
                Console.WriteLine("Escolha (A,B,C,D,E,ou S): \n");

                escolha = Console.ReadLine();

                switch (escolha)
                {
                    case "A":
                        
                        auxUrg.AdicionaUtente();
                        break;

                    case "B":
                        Console.WriteLine("Escreva 'proximo' ou 'next' quando estiver disponivel.");
                        nov= auxUrg.Triagem();
                        
                        break;
                    case "C":
                        if (nov == null)
                        {
                            Console.WriteLine("Não existem utentes na urgencia");
                        }
                        else
                        {
                            auxUrg.UrgenciaGeral(nov);
                        }
                        break;
                    case "D":
                        Console.WriteLine("Identificar a posição do Funcionario medico:");
                        Console.WriteLine("Medico ou enfermeiro ?");
                        aux = Console.ReadLine();
                        auxHosp.AdicionaFuncionarioMedico(aux);
                        break;
                    case "E":
                        Console.WriteLine("Pretende adicionar medico ou enfermeiro?");
                        aux = Console.ReadLine();
                        auxUrg.DeServicoNaUrgencia(aux);
                        break;
                    case "S":
                        Console.WriteLine("___---____---___");
                        System.Environment.Exit(1);
                        break;
                        


                    default:
                        Console.WriteLine("{0} escolha invalida.", escolha);
                        break;




                }

                Console.Write("Press Enter to continue...\n");
                Console.ReadLine();
                Console.WriteLine();

            } while (escolha != "s" || escolha != "sair");

        }
           
    }
}
