﻿using System;

namespace LP2_trabalho
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu novmen = new Menu();
            novmen.Menux();
        }
    }
}
