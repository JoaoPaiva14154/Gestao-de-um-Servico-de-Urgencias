﻿/*      Trabalho Prático LP2
 *  |Gestão Urgência|
 * 
 *  José Paulo Antunes      a11582@alunos.ipca.pt
 *  João Paiva              a14154@alunos.ipca.pt
 *  
 *  IPCA 2019/2020
 */

using System;

namespace LP2_trabalho
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu novmen = new Menu();
            novmen.Menux();
        }
    }
}
