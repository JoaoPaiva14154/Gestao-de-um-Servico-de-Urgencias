﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LP2_trabalho
{
    class Urgencia : Hospital
    {

        #region ATRIB
        int numeroDeUtentes = 0;
        int numeroDeMedicos = 0;
        int numeroDeEnfermeiros = 0;
        Utente[] totUtente = new Utente[50];
        Medico[] medDeUrgencia = new Medico[10];
        Enfermeiro[] enfDeUrgencia = new Enfermeiro[30];
        LinkedList<Utente> list_triagem = new LinkedList<Utente>();
        LinkedList<Utente> list_urgencia = new LinkedList<Utente>();

        



        #endregion

        #region METODOS
        /// <summary>
        /// adiciona utente
        /// </summary>
        /// <returns></returns>
        public void AdicionaUtente()
        {

            Console.WriteLine("Nome do Utente");
            string nome = Console.ReadLine();
            Console.WriteLine("Região do utente");
            string regiao = Console.ReadLine();
            Console.WriteLine("Sexo do utente");
            string sexo = Console.ReadLine();
            Console.WriteLine("Data de Nascimento ");
            Console.WriteLine("ano");
            int aux1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Mes(numero)");
            int aux2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Dia");
            int aux3 = int.Parse(Console.ReadLine());
            DateTime dataNascimento = new DateTime(aux1,aux2,aux3);


          totUtente[numeroDeUtentes] = new Utente(nome, regiao, sexo, dataNascimento, DateTime.Now.ToString());
          totUtente[numeroDeUtentes].Idade = (int.Parse(DateTime.Now.ToString("yyyyMMdd")) - int.Parse(dataNascimento.ToString("yyyyMMdd"))) / 10000;

          LinkedListNode<Utente> utentex = new LinkedListNode<Utente>(totUtente[numeroDeUtentes]);
          list_triagem.AddLast(utentex);



        }
        /// <summary>
        /// De serviço para Medico ou enfermeiro
        /// </summary>
        /// <param name="posicao">Medico ou enf</param>
        public void DeServicoNaUrgencia(string posicao) 
        {
            if (posicao == "medico" || posicao == "med")
            {
                Console.WriteLine("Qual o numero do medico que vai entrar na urgencia?");
                int aux = int.Parse(Console.ReadLine());
                for (int i = 0; i < totMed.Length; i++)
                {
                    if (aux == totMed[i].NumMedico)
                    {
                        totMed[i].NaUrgencia = true;  //vai modificar informaçao ao get set

                        medDeUrgencia[numeroDeMedicos] = totMed[i];

                        numeroDeMedicos += 1;

                    }

                }
            }

            else if(posicao == "enfermeiro" || posicao == "enf") 
            {

                Console.WriteLine("Qual o numero do Enfermeiro que vai entrar na urgencia?");
                int aux = int.Parse(Console.ReadLine());


                //completar usar o de cima como template, feel free para modificares o que aches necessario em cima 


            }

        }


        public LinkedListNode<Utente> Triagem()
        {
          Utente aux1;
          string aux =  Console.ReadLine();

            if (aux == "next" || aux == "proximo") 
            {
                if (list_triagem.First != null && list_triagem.Last != null) 
                {
                    Console.WriteLine("Dados do Utente");
                    aux1 = list_triagem.First.Value;

                    Console.WriteLine("{0}",aux1.Nome);
                    Console.WriteLine("{0}", aux1.Idade);
                    Console.WriteLine("{0}", aux1.Sexo);
                    Console.WriteLine("{0}", aux1.Regiao);
                    Console.WriteLine("___----____----____");
                    Console.WriteLine("___----____----____");

                    Console.WriteLine("Qual a pulseira do Utente?");
                    string pulseira = Console.ReadLine();
                    aux1.Estado = pulseira;
                    aux1.Atendido = "nao";


                    LinkedListNode<Utente> utenteUrg = new LinkedListNode<Utente>(aux1);
                    list_urgencia.AddLast(utenteUrg);
                    list_triagem.RemoveFirst();

                    return utenteUrg;

                }
                if (list_triagem.First == null && list_triagem.Last == null)
                {
                    Console.WriteLine("Não ha novos utentens para triagem");
                    return null;
                }

            }
            return null;



        }

        public void UrgenciaGeral(LinkedListNode<Utente>lln)
        {
            Utente aux1;
            string aux = Console.ReadLine();
            bool atend = true;
            int aux2=0;

            if (aux == "next" || aux == "proximo")
            {
                if (list_urgencia.First != null && list_urgencia.Last != null)
                {
                    int count = list_urgencia.Count;

                    //para pulseira vermelha
                    for (int i = 0; i <= count; i++)
                    {
                        if (lln.Value != null)
                        {
                            if (lln.Value.Estado == "vermelha" || lln.Value.Estado == "vermelho" || lln.Value.Estado == "red")
                            {
                                if (lln.Value.Atendido != "sim")
                                {
                                    aux1 = lln.Value;
                                    Console.WriteLine("{0}", aux1.Nome);
                                    Console.WriteLine("{0}", aux1.Idade);
                                    Console.WriteLine("{0}", aux1.Sexo);
                                    Console.WriteLine("{0}", aux1.Regiao);
                                    Console.WriteLine("{0}", aux1.Estado);
                                    Console.WriteLine("___----____----____");
                                    Console.WriteLine("___----____----____");
                                    lln.Value.Atendido = "sim";
                                }


                            }
                            else 
                            {

                               
                                lln = lln.Next;
                               
                            }
                        }

                    }
                    //amarela
                    for (int i = 0; i <= count; i++)
                    {
                        
                            if (lln.Value.Estado == "amarela" || lln.Value.Estado == "amarelo" || lln.Value.Estado == "yellow")
                            {
                                if (lln.Value.Atendido != "sim")
                                {
                                aux1 = lln.Value;
                                Console.WriteLine("%0", aux1.Nome);
                                Console.WriteLine("%0", aux1.Idade);
                                Console.WriteLine("%0", aux1.Sexo);
                                Console.WriteLine("%0", aux1.Regiao);
                                Console.WriteLine("%0", aux1.Estado);
                                Console.WriteLine("___----____----____");
                                Console.WriteLine("___----____----____");
                                lln.Value.Atendido = "sim";
                                }

                             }
                            else
                            {

                                
                                    lln = lln.Next;
                                
                            }
                        

                    }
                    //verde
                    for (int i = 0; i <= count; i++)
                    {
                       
                            if (lln.Value.Estado == "verde" || lln.Value.Estado == "green")
                            {
                                if (lln.Value.Atendido != "sim")
                                {

                                aux1 = lln.Value;
                                Console.WriteLine("%0", aux1.Nome);
                                Console.WriteLine("%0", aux1.Idade);
                                Console.WriteLine("%0", aux1.Sexo);
                                Console.WriteLine("%0", aux1.Regiao);
                                Console.WriteLine("%0", aux1.Estado);
                                Console.WriteLine("___----____----____");
                                Console.WriteLine("___----____----____");
                                lln.Value.Atendido = "sim";

                                }
                            }
                            else
                            {

                              
                                    lln = lln.Next;
                                
                            }



                    }

                    for (int i = 0; i <= count; i++)
                    {
                        if (lln.Value.Atendido == "nao")
                        {

                            atend = false;
                            aux2++;
                            if (lln.Next != null)
                            {
                                lln = lln.Next;
                            }
                        }

                    }
                    if (atend == true)
                    {
                        Console.WriteLine("Todos os utentes ja foram atendidos");
                    }
                    else 
                    {
                        Console.WriteLine("Faltam ser atendidos %0 utentes", aux2);
                    }




                }
            }




        }


        #endregion  



    }
}
